<?php
$lang = array (
		'homepage' => "Homepage",
		'contact' => 'Contact',
		'cart' => 'Cart',
		'totalitems' => 'Total items',
		'totalprice' => 'Total price',
		'search' => 'Search',
		'enterkeyword' => 'Enter keywords',
		'latestproduct' => 'Latest product',
		'featuredproducts' => 'Featured Products',
		'news' => 'News',
);
?>