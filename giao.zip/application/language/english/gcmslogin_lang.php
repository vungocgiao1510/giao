<?php 
$lang = array(
		'user' => 'Username',
);
?>