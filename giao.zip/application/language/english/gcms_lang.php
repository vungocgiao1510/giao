<?php
$lang = array (
		'dashboard' => 'Dashboard',
);