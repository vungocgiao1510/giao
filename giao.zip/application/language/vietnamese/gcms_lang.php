<?php
$lang = array (
		'dashboard' => 'Bảng điều khiển',
);