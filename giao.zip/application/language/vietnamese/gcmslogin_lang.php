<?php
$lang = array (
		'user' => 'Tài khoản',
		'pass' => 'Mật khẩu',
		'lang' => 'Ngôn ngữ',
		'vi' => 'Vietnamese',
		'en' => 'English',
		'cn' => 'China',
		'logingcms' => 'Đăng nhập hệ thống',
		'submit' => 'Đăng nhập' 
);
?>