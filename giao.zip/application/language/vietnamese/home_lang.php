<?php
$lang = array (
		'homepage' => "Trang chủ",
		'contact' => 'Liên hệ',
		'cart' => 'Giỏ hàng',
		'totalitems' => 'Số lượng',
		'totalprice' => 'Tổng tiền',
		'search' => 'Tìm kiếm',
		'enterkeyword' => 'Nhập vào từ khóa',
		'latestproduct' => 'Sản phẩm mới nhất',
		'featuredproducts' => 'Sản phẩm nổi bật',
		'news' => 'Tin tức' 
);
?>