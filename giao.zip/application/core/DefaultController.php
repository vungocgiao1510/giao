<?php 
class DefaultController extends MY_Controller {
	protected $_data;
	public function __construct(){
		
	}
}
?>