<div class="container">
 <div class="col-md-12">
  <ol class="breadcrumb">
    <li><a href="<?php echo base_url().$lang ?>"><?php echo $this->lang->line("homepage"); ?></a></li>
    <li class="active">Gửi thông tin thành công</li>
  </ol>
 	<div class="panel panel-default">
	  <div class="panel-body">


	  		<p align="center">Gửi thông tin thành công, chúng tôi sẽ sớm phản hồi gần nhất cho bạn.</p>


	  </div>
	</div>
 </div>
</div>