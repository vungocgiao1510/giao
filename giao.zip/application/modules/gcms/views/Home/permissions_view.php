<div align="center" class="alert alert-danger" role="alert">
<?php echo $error ?> <br />
Bấm vào đây để quay trở về <a href="<?php echo base_url()."gcms/home/index"; ?>">Trang Chủ</a>
</div>
<img src="<?php echo base_url()."public/gcms/img/403_Error.png"; ?>" alt="403 Error" title="403 Error" class="img-responsive" />